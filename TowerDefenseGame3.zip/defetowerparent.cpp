#include "defetowerparent.h"

int DefeTowerParent::GetX() const     //获取横坐标
{
    return mx;
}

int DefeTowerParent::GetY() const     //获取横坐标
{
    return my;
}

int DefeTowerParent::GetWidth() const //获取宽
{
    return width;
}

int DefeTowerParent::GetHeight() const //获取高
{
    return height;
}

QString DefeTowerParent::GetBaseImgPath() const  //获取底座图片路径
{
    return BaseImgPath;
}

QString DefeTowerParent::GetDefImgPath() const   //获取防御塔图片路径
{
    return DefImgPath;
}

int DefeTowerParent::GetUpLeftX() const     //获取防御塔左上角原横坐标
{
    return UpLeftX;
}

int DefeTowerParent::GetUpLeftY() const     //获取防御塔左上角原纵坐标
{
    return UpLeftY;
}

