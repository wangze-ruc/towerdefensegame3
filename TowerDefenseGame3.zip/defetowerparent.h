#ifndef DEFETOWERPARENT_H
#define DEFETOWERPARENT_H

#include <QString>

//防御塔父类
class DefeTowerParent
{
//防御塔属性
protected:
    int mx, my;             //坐标
    int width, height;      //宽高
    QString BaseImgPath;    //防御塔底座图片路径
    QString DefImgPath;     //防御塔图片路径
    int UpLeftX, UpLeftY;   //防御塔塔坑原坐标

public:
    int GetX() const;       //获取横坐标
    int GetY() const;       //获取横坐标
    int GetWidth() const;   //获取宽
    int GetHeight() const;  //获取高
    QString GetBaseImgPath() const; //获取底座图片路径
    QString GetDefImgPath() const;  //获取防御塔图片路径
    int GetUpLeftX() const; //获取防御塔左上角原横坐标
    int GetUpLeftY() const; //获取防御塔左上角原纵坐标
};

#endif // DEFETOWERPARENT_H
