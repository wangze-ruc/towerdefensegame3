
#include "startfrom.h"      //开始场景
#include <QApplication>

#include <QMediaPlayer>
#include <QVideoWidget>

int main(int argc, char *argv[])
{

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/sound/hdl.mp3"));
    player->setVolume(30);
    player->play();


    QApplication a(argc, argv);
    StartFrom w;
    w.show();

    return a.exec();
}
