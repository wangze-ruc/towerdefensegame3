#include "fireturret.h"

//火防御塔类函数实现
//构造
FireTurret::FireTurret(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight)
{
    //初始化成员变量，这里不能用初始化列表
    mx = x, my = y;
    BaseImgPath = QString(":/image/火瓶底座.png");
    DefImgPath = QString(":/image/二级火瓶.png");
    width = Fwidth, height = Fheight;
    UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

}
